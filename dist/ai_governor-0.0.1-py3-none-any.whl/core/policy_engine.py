"""
Policy Engine

Evaluates governance policies against LLM requests and responses.
Returns deterministic ALLOW / BLOCK / MODIFY decisions.
"""

